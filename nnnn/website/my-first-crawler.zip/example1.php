<?php
include_once('simple_html_dom.php');
phpinfo();
?>